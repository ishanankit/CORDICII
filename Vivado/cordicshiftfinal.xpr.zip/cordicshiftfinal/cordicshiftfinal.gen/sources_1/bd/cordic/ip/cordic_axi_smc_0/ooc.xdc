# aclk {FREQ_HZ 25000000 CLK_DOMAIN cordic_processing_system7_0_0_FCLK_CLK0 PHASE 0.0}
# Clock Domain: cordic_processing_system7_0_0_FCLK_CLK0
create_clock -name aclk -period 40.000 [get_ports aclk]
# Generated clocks
