`timescale 1ns / 1ps

module tb_top;

    // ===========================
    // Inputs and outputs
    // ===========================
    reg  signed [31:0] x;
    reg  signed [31:0] y;
    reg  signed [31:0] z;
    reg  clk;

    wire signed [31:0] x1;
    wire signed [31:0] y1;
    wire signed [31:0] z1;

    // ===========================
    // Instantiate DUT
    // ===========================
    top dut(
        .x(x),
        .y(y),
        .z(z),
        .clk(clk),
        .x1(x1),
        .y1(y1),
        .z1(z1)
    );

    // ===========================
    // Generate 100 MHz clock
    // ===========================
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // ===========================
    // Q8.23 Scale
    // ===========================
    localparam signed [31:0] SCALE = 32'sd8388608;  // 1.0

    // ===========================
    // TASK - prints results
    // ===========================
    task show_result;
        input [31:0] angle;
        begin
            $display("-----------------------------------------");
            $display(" Rotating by %0d degrees", angle);
            $display("-----------------------------------------");
            $display(" Input X = %f  (0x%08h)",  $itor(x)/SCALE , x);
            $display(" Input Y = %f  (0x%08h)",  $itor(y)/SCALE , y);
            $display(" Input Z = %f° (0x%08h)", $itor(angle), z);
            #300;  // wait CORDIC pipeline

            $display("\n Output X = %f  (0x%08h)", $itor(x1)/SCALE, x1);
            $display(" Output Y = %f  (0x%08h)\n", $itor(y1)/SCALE, y1);
        end
    endtask

    // ===========================
    // TEST VECTOR PROCEDURE
    // ===========================
    initial begin
        #50;

        x = SCALE;
        y = 0;

        // 5 degrees
        z = 32'h02800000;
        #20 show_result(5);

        // 10°
        z = 32'h05000000;
        #20 show_result(10);

        // 30°
        z = 32'h0F000000;
        #20 show_result(30);

        // 45°
        z = 32'h16800000;
        #20 show_result(45);

        // 60°
        z = 32'h1E000000;
        #20 show_result(60);

        // 90°
        z = 32'h2D000000;
        #20 show_result(90);

        // 120°
        z = 32'h3C000000;
        #20 show_result(120);

        // 180°
        z = 32'h5A000000;
        #20 show_result(180);

        // -45°
        z = 32'hE9800000;
        #20 show_result(-45);

        $display("=== ALL DONE ===");
        #100 $finish;
    end

endmodule
