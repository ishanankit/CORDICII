transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib riviera/xilinx_vip
vlib riviera/xil_defaultlib
vlib riviera/axi_infrastructure_v1_1_0
vlib riviera/axi_vip_v1_1_21
vlib riviera/processing_system7_vip_v1_0_23
vlib riviera/axi_lite_ipif_v3_0_4
vlib riviera/interrupt_control_v3_1_5
vlib riviera/axi_gpio_v2_0_37
vlib riviera/xlconstant_v1_1_10
vlib riviera/proc_sys_reset_v5_0_17
vlib riviera/smartconnect_v1_0
vlib riviera/axi_register_slice_v2_1_35

vmap xilinx_vip riviera/xilinx_vip
vmap xil_defaultlib riviera/xil_defaultlib
vmap axi_infrastructure_v1_1_0 riviera/axi_infrastructure_v1_1_0
vmap axi_vip_v1_1_21 riviera/axi_vip_v1_1_21
vmap processing_system7_vip_v1_0_23 riviera/processing_system7_vip_v1_0_23
vmap axi_lite_ipif_v3_0_4 riviera/axi_lite_ipif_v3_0_4
vmap interrupt_control_v3_1_5 riviera/interrupt_control_v3_1_5
vmap axi_gpio_v2_0_37 riviera/axi_gpio_v2_0_37
vmap xlconstant_v1_1_10 riviera/xlconstant_v1_1_10
vmap proc_sys_reset_v5_0_17 riviera/proc_sys_reset_v5_0_17
vmap smartconnect_v1_0 riviera/smartconnect_v1_0
vmap axi_register_slice_v2_1_35 riviera/axi_register_slice_v2_1_35

vlog -work xilinx_vip  -incr "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"C:/Xilinx/2025.1/Vivado/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"C:/Xilinx/2025.1/Vivado/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"C:/Xilinx/2025.1/Vivado/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"C:/Xilinx/2025.1/Vivado/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"C:/Xilinx/2025.1/Vivado/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"C:/Xilinx/2025.1/Vivado/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"C:/Xilinx/2025.1/Vivado/data/xilinx_vip/hdl/axi_vip_if.sv" \
"C:/Xilinx/2025.1/Vivado/data/xilinx_vip/hdl/clk_vip_if.sv" \
"C:/Xilinx/2025.1/Vivado/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work xil_defaultlib  -incr -v2k5 "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_top_0_0/sim/cordic_top_0_0.v" \

vlog -work axi_infrastructure_v1_1_0  -incr -v2k5 "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \

vlog -work axi_vip_v1_1_21  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f16f/hdl/axi_vip_v1_1_vl_rfs.sv" \

vlog -work processing_system7_vip_v1_0_23  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl/processing_system7_vip_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -incr -v2k5 "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_processing_system7_0_0/sim/cordic_processing_system7_0_0.v" \

vcom -work axi_lite_ipif_v3_0_4 -93  -incr \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/66ea/hdl/axi_lite_ipif_v3_0_vh_rfs.vhd" \

vcom -work interrupt_control_v3_1_5 -93  -incr \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/d8cc/hdl/interrupt_control_v3_1_vh_rfs.vhd" \

vcom -work axi_gpio_v2_0_37 -93  -incr \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/0271/hdl/axi_gpio_v2_0_vh_rfs.vhd" \

vcom -work xil_defaultlib -93  -incr \
"../../../bd/cordic/ip/cordic_axi_gpio_0_0/sim/cordic_axi_gpio_0_0.vhd" \
"../../../bd/cordic/ip/cordic_axi_gpio_1_0/sim/cordic_axi_gpio_1_0.vhd" \
"../../../bd/cordic/ip/cordic_axi_gpio_2_0/sim/cordic_axi_gpio_2_0.vhd" \

vlog -work xlconstant_v1_1_10  -incr -v2k5 "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a165/hdl/xlconstant_v1_1_vl_rfs.v" \

vlog -work xil_defaultlib  -incr -v2k5 "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_0/sim/bd_2f62_one_0.v" \

vcom -work proc_sys_reset_v5_0_17 -93  -incr \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/9438/hdl/proc_sys_reset_v5_0_vh_rfs.vhd" \

vcom -work xil_defaultlib -93  -incr \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_1/sim/bd_2f62_psr_aclk_0.vhd" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/sc_util_v1_0_vl_rfs.sv" \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/3718/hdl/sc_switchboard_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_2/sim/bd_2f62_arinsw_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_3/sim/bd_2f62_rinsw_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_4/sim/bd_2f62_awinsw_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_5/sim/bd_2f62_winsw_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_6/sim/bd_2f62_binsw_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_7/sim/bd_2f62_aroutsw_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_8/sim/bd_2f62_routsw_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_9/sim/bd_2f62_awoutsw_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_10/sim/bd_2f62_woutsw_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_11/sim/bd_2f62_boutsw_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/sc_node_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_12/sim/bd_2f62_arni_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_13/sim/bd_2f62_rni_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_14/sim/bd_2f62_awni_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_15/sim/bd_2f62_wni_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_16/sim/bd_2f62_bni_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/d800/hdl/sc_mmu_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_17/sim/bd_2f62_s00mmu_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/2da8/hdl/sc_transaction_regulator_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_18/sim/bd_2f62_s00tr_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/dce3/hdl/sc_si_converter_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_19/sim/bd_2f62_s00sic_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/cef3/hdl/sc_axi2sc_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_20/sim/bd_2f62_s00a2s_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_21/sim/bd_2f62_sarn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_22/sim/bd_2f62_srn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_23/sim/bd_2f62_sawn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_24/sim/bd_2f62_swn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_25/sim/bd_2f62_sbn_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/7f4f/hdl/sc_sc2axi_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_26/sim/bd_2f62_m00s2a_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_27/sim/bd_2f62_m00arn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_28/sim/bd_2f62_m00rn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_29/sim/bd_2f62_m00awn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_30/sim/bd_2f62_m00wn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_31/sim/bd_2f62_m00bn_0.sv" \

vlog -work smartconnect_v1_0  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/0133/hdl/sc_exit_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_32/sim/bd_2f62_m00e_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_33/sim/bd_2f62_m01s2a_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_34/sim/bd_2f62_m01arn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_35/sim/bd_2f62_m01rn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_36/sim/bd_2f62_m01awn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_37/sim/bd_2f62_m01wn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_38/sim/bd_2f62_m01bn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_39/sim/bd_2f62_m01e_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_40/sim/bd_2f62_m02s2a_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_41/sim/bd_2f62_m02arn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_42/sim/bd_2f62_m02rn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_43/sim/bd_2f62_m02awn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_44/sim/bd_2f62_m02wn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_45/sim/bd_2f62_m02bn_0.sv" \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/ip/ip_46/sim/bd_2f62_m02e_0.sv" \

vlog -work xil_defaultlib  -incr -v2k5 "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/bd_0/sim/bd_2f62.v" \

vlog -work axi_register_slice_v2_1_35  -incr -v2k5 "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/c5b7/hdl/axi_register_slice_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib  -incr "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/ip/cordic_axi_smc_0/sim/cordic_axi_smc_0.sv" \

vcom -work xil_defaultlib -93  -incr \
"../../../bd/cordic/ip/cordic_rst_ps7_0_100M_0/sim/cordic_rst_ps7_0_100M_0.vhd" \

vlog -work xil_defaultlib  -incr -v2k5 "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/ec67/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/6cfa/hdl" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/f0b6/hdl/verilog" "+incdir+../../../../cordicshiftfinal.gen/sources_1/bd/cordic/ipshared/a8e4/hdl/verilog" "+incdir+../../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+C:/Xilinx/2025.1/Vivado/data/xilinx_vip/include" -l xilinx_vip -l xil_defaultlib -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_21 -l processing_system7_vip_v1_0_23 -l axi_lite_ipif_v3_0_4 -l interrupt_control_v3_1_5 -l axi_gpio_v2_0_37 -l xlconstant_v1_1_10 -l proc_sys_reset_v5_0_17 -l smartconnect_v1_0 -l axi_register_slice_v2_1_35 \
"../../../bd/cordic/sim/cordic.v" \

vlog -work xil_defaultlib \
"glbl.v"

